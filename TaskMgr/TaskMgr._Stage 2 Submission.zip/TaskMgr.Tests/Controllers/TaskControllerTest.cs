﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace TaskMgr.Tests.Controllers
{
    [TestClass]
    public class TaskControllerTest
    {
        [TestMethod]
        public void All_RetrievesTaskList()
        {
        }

        [TestMethod]
        public void Get_ExistingTask()
        {
        }

        [TestMethod]
        public void Get_NonExistingTask()
        {
        }

        [TestMethod]
        public void Update_ExistingTask()
        {
        }

        [TestMethod]
        public void Update_NonExistingTask()
        {
        }

        [TestMethod]
        public void End_Task()
        {
        }        
    }
}
