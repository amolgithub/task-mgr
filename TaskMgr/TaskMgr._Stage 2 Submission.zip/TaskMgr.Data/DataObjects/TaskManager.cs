﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TaskMgr.Data.Entities;

namespace TaskMgr.Data.DataObjects
{
    public class TaskManager
    {
        public IEnumerable<Task> GetTasks()
        {
            return null;
        }

        public Task GetTask(int taskId)
        {
            return null;
        }

        public void UpdateTask(Task modifiedTask)
        {

        }
    }
}
